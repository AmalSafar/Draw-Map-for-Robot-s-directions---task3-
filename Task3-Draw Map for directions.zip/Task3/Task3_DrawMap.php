<?php
 require_once 'C:\Users\amals\Documents\Xampp\htdocs\Task3\dataConn.php';
?>
<!DOCTPE html>
<html>
	<head>
		<meta charset="utf.8">
		<title> Robot </title>
		<link rel="stylesheet" herf="style.css" />
	</head>
	<script>
function drawLine(var F,var R) 
{
var canvas = document.getElementById('myCanvas'); 
var context = canvas.getContext('2d');

context.beginPath();
context.moveTo(50,50);
context.lineTo(F,R);
context.stroke();
}
</script>
	<body>
		<h1> Task 3 - Draw Map </h1>
		<style>
		background:lightgray;
		input {width:100px}
		#Forward{position:fixed; top : 30%; left: 10%; width : 5%;padding : 10px ;background:white;color: black;}
		#Left{position:fixed;	 top : 39%;	left: 10%; width : 5%;padding : 10px ;background:white;color: black;}
		#Right{position:fixed;   top : 48%; left: 10%; width : 5%;padding : 10px ;background:white;color: black;}
		#Filed1{position:fixed;  top : 31%; left: 20%; width : 10%;}
		#Filed2{position:fixed;	 top : 40%;	left: 20%; width : 10%;}
		#Filed3{position:fixed;  top : 49%; left: 20%; width : 10%;}
		#Start{position:fixed;   top : 20%; left: 10%; width : 5%;padding : 10px ;background:green;color: black;}
		#Save{position:fixed;    top : 20%; left: 20%; width : 5%;padding : 10px ;background:white;color: black;}
		#Delete{position:fixed;  top : 20%; left: 30%; width : 5%;padding : 10px ;background:red;  color: black;}
	    div{position:fixed;top : 30%;left: 28%;}
		</style>
			<div class="controller">
			<form action="" method="POST">			
				<br>
				<button  id="Save"    type="submit" title="Save"      name="Save" class="btn btn-secondary">Save</button>
				<button  id="Delete"  type="submit" title="Delete"    name="Delete" class="btn btn-secondary" >Delete</button>
				<button  id="Start"   type="submit" title="Start"     name="Start" class="btn btn-secondary" >Start</button>
				<br>
				<button  id="Right"   type="submit" title="Right"     name="R"  >Right</button>
				<button  id="Left" 	  type="submit" title="Left"      name="L" >Left</button>
				<button  id="Forward" type="submit" title="Forward"   name="F"  >Forward</button>
				<br>
				<input  id="Filed1" type="text" title="Forward"   name="For" >
				<input  id="Filed2" type="text" title="Left"      name="Lef" >
				<input  id="Filed3" type="text" title="Rigth"     name="Rig" >
			</form>	
			</div>
	
	<?php
		if($_SERVER['REQUEST_METHOD'] === 'POST'){
			$right= (int) $_POST['Rig'];
			$forward= (int) $_POST['For'];
			$left= (int) $_POST['Lef'];	
			if(isset($_POST["Save"])){	
				$sql= "INSERT INTO `ManuallyDirection` (`Right`, `Forward`, `Left`) VALUES ($right , $forward , $left)";
				if(mysqli_query($database, $sql)){
					echo"";
				}else{
					echo "ERROR";
				}
			$result= "SELECT `Right`, `Forward`, `Left` FROM `ManuallyDirection` ";
			echo "<center><h2>Robot Tracking</h2>";
			echo "<center><table border='1'>
			<tr>
			<th>Right</th>
			<th>Forward</th>
			<th>Left</th>			
			</tr>";
			if($result = $database->query($result)){
				while($row = $result->fetch_assoc())
				{
					echo "<tr>";
					echo "<td>" . $row['Right'] . "</td>";
					echo "<td>" . $row['Forward'] . "</td>";
					echo "<td>" . $row['Left'] . "</td>";
				}
				echo "</table>";
			}
			mysqli_close($database);
			} elseif( isset($_POST["Delete"])){
			$right= '';
			$forward= '';
			$left= '';
			} elseif(isset($_POST["Start"])){
				echo "Robot is ready, enter directions to start!";
				echo "Note : The circle is center postion.";
				echo '<center><svg height="500" width="400" style="background-color:lightgray; position:fixed; top : 15%; left: 70%;">
					<circle cx="200" cy="200" r="5" stroke="red" stroke-width="3" fill="red" />
					</svg>';
				
			} elseif(isset($_POST["F"])){
				echo '<center><svg height="500" width="400" style="background-color:lightgray; position:fixed; top : 15%; left: 70%;">
				<path d="M200 200 V30 '.$forward.'" stroke="black" stroke-width="3" fill="none"/>
					<circle cx="200" cy="200" r="5" stroke="red" stroke-width="3" fill="red" />
					</svg>';
					$forward= 0;
			}elseif (isset($_POST["L"])){
				$left= 200-(int)$left;
				echo '<center><svg height="500" width="400" style="background-color:lightgray; position:fixed; top : 15%; left: 70%;">
				<path d="M200 200 H '.$left.' '.$left.' " stroke="black" stroke-width="3" fill="none"/>
					<circle cx="200" cy="200" r="5" stroke="red" stroke-width="3" fill="red" />
					</svg>';
					$left= 0;
			}elseif (isset($_POST["R"])){
				$right= 200+(int)$right;
				echo '<center><svg height="500" width="400" style="background-color:lightgray; position:fixed; top : 15%; left: 70%;">
				<path d="M200 200 H '.$right.' '.$right.' " stroke="black" stroke-width="3" fill="none"/>
					<circle cx="200" cy="200" r="5" stroke="red" stroke-width="3" fill="red" />
					</svg>';
					$right= 0;
			}
			}
	?>
	</body>
</html>

